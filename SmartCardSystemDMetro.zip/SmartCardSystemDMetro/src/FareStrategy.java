public interface FareStrategy {
    String getName();

    double getFarePerStation();
}
